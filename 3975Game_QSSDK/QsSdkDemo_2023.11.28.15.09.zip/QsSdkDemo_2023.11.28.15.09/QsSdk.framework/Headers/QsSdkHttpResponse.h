



@interface QsSdkHttpResponse : NSObject

@property (nonatomic, retain) NSString *codeQsSdk;
@property (nonatomic, retain) NSString *msgQsSdk;
@property (nonatomic, retain) NSDictionary *dataQsSdk;

@end
