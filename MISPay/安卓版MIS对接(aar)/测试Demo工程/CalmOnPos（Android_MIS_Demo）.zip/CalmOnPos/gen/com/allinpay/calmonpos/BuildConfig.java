/** Automatically generated file. DO NOT MODIFY */
package com.allinpay.calmonpos;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}