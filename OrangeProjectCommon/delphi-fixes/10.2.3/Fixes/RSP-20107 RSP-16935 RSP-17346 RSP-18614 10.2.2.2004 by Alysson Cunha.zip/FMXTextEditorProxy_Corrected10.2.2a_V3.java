﻿package com.embarcadero.firemonkey.text;

import java.util.ArrayList;
import java.util.Arrays;

import android.annotation.SuppressLint;
import android.content.ClipData;
import android.content.Context;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.ResultReceiver;
import android.text.Editable;
import android.text.InputFilter;
import android.text.InputType;
import android.text.Selection;
import android.text.SpanWatcher;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.SpannableStringBuilder;
import android.text.Spanned;
import android.text.TextUtils;
import android.text.TextWatcher;

import com.embarcadero.firemonkey.text.FMXTextListener;
import android.util.AttributeSet;
import android.util.Log;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.inputmethod.BaseInputConnection;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.ExtractedText;
import android.view.inputmethod.ExtractedTextRequest;
import android.view.inputmethod.InputConnection;
import android.view.inputmethod.InputMethodManager;

class TextLineSpan implements Comparable<TextLineSpan> {
	private int lineNumber;
	
	public TextLineSpan(int line) {
		lineNumber = line;
	}
	
	public int getLineNumber() {
		return lineNumber;
	}
	
	public void setLineNumber(int line) {
		lineNumber = line;
	}

	@Override
	public int compareTo(TextLineSpan o) {
		return new Integer(lineNumber).compareTo(new Integer(o.lineNumber));
	}
}

public class FMXTextEditorProxy extends View {
	public final static int INPUT_TEXT = 0;
	public final static int INPUT_NUMBER = 1;
	public final static int INPUT_NUMBER_AND_PUNCTUATION = 2;
	public final static int INPUT_PHONE = 3;
	public final static int INPUT_ALPHABET = 4;
	public final static int INPUT_URL = 5;
	public final static int INPUT_NAME_PHONE_PAD = 6;
	public final static int INPUT_EMAIL_ADDRESS = 7;
	public final static int INPUT_NUMBER_DECIMAL = 8;

	public final static int ACTION_ENTER = 0;
	public final static int ACTION_NEXT = 1;
	public final static int ACTION_DONE = 2;
	public final static int ACTION_GO = 3;
	public final static int ACTION_SEARCH = 4;
	public final static int ACTION_SEND = 5;

	public final static int CHARCASE_NORMAL = 0;
	public final static int CHARCASE_UPPER = 1;
	public final static int CHARCASE_LOWER = 2;

	private static final boolean DEBUG = false;
	private static final String TAG = "FMXTextEditorProxy";
	private static final String mlineBreak = System.getProperty("line.separator");
	private static final CharSequence EMPTY_CHARS = "";

	private Editable mEditable = null;
	private ProxyInputConnection mInputConnection = null;
	private boolean mReadOnly = false;
	private boolean mPassword = false;
	private boolean mMultiline = true;

	private int mInputType = INPUT_TEXT;
	private int mEnterAction = ACTION_ENTER;
	private int mMaxLength = 0;
	private int mCharCase = CHARCASE_NORMAL;
	private CharSequence mFilterChar;

	private ChangeWatcher mChangeWatcher = null;

	private ArrayList<FMXTextListener> mListeners;
	private OnEnterActionListener mOnEnterActionListener;
	private ArrayList<VKStateChangeListener> mVKListeners;

	private boolean mSkipRestart = false;

	public interface OnEnterActionListener {
		boolean onAction(FMXTextEditorProxy v, int actionId, KeyEvent event);
	}

	public FMXTextEditorProxy(Context context) {
		super(context);
		init(context, null, 0);
	}

	public FMXTextEditorProxy(Context context, AttributeSet attrs) {
		super(context, attrs);
		init(context, attrs, 0);
	}

	public FMXTextEditorProxy(Context context, AttributeSet attrs, int defStyle) {
		super(context, attrs, defStyle);
		init(context, attrs, defStyle);
	}

	private void init(Context context, AttributeSet attrs, int defStyle) {
		setFocusable(true);
		setFocusableInTouchMode(true);
		setClickable(true);
	}

	public CharSequence getText() {
		return getEditable();
	}

	private CharSequence unpackText(CharSequence text) {
		if (DEBUG) Log.v(TAG, "[unpackText] text: " + text);
		StringBuilder builder = new StringBuilder(text.length());
		if (text.length() > 0) {
			String textStr = text.toString();
			int headerBegin = textStr.indexOf("[");
			int headerEnd = textStr.indexOf("]");
			if (headerBegin >= 0 && headerEnd > 0 && (headerEnd - headerBegin - 1) > 0) {
				String[] header = textStr.substring(headerBegin + 1, headerEnd).split(",");
				int lengthBefore = 0;
				for (int i = 0; i < header.length; ++i) {
					if (i > 0)
						builder.append(mlineBreak);
					int lineLength = Integer.parseInt(header[i]);
					if (lineLength > 0) {
						int indexShift = headerEnd + 1 + lengthBefore;
						builder.append(textStr.substring(indexShift, indexShift + lineLength));
					}
					lengthBefore += lineLength;
				}
			}
		}
		return builder.toString();
	}

	public CharSequence packText(Spannable editable) {
		int length = editable.length();

		if (length <= 0)
			return EMPTY_CHARS;
		if (DEBUG) Log.v(TAG, "[packText] before: " + editable.toString());
		TextLineSpan[] spans = editable.getSpans(0, editable.length(), TextLineSpan.class);
		Arrays.sort(spans);
		StringBuilder header = new StringBuilder(spans.length * 4);
		StringBuilder body = new StringBuilder(length);
		for (TextLineSpan span : spans) {
			if (header.length() > 0)
				header.append(',');
			int start = editable.getSpanStart(span);
			int end = editable.getSpanEnd(span);
			String line = editable.subSequence(start, end).toString();
			header.append(line.length());
			body.append(line);
		}
		String result = "";
//    if (header.length() > 0)
//      result = new StringBuilder().append("[").append(header.toString()).append("]").append(body.toString()).toString();		
		if (header.length() > 0)
			result = "[" + header.toString() + "]" + body.toString();
		return result.subSequence(0, result.length());
	}

	private void setLineSpans(CharSequence text) {
		if (DEBUG) Log.v(TAG, "[setLineSpans] text: " + text);
		TextLineSpan[] spans = mEditable.getSpans(0, mEditable.length(), TextLineSpan.class);
		for (TextLineSpan span : spans)
			mEditable.removeSpan(span);

		if (text.length() > 0) {
			String textStr = text.toString();
			int headerBegin = textStr.indexOf("[");
			int headerEnd = textStr.indexOf("]");
			if (headerBegin >= 0 && headerEnd > 0) {
				int lineBreakLength = mlineBreak.length();
				String[] header = textStr.substring(headerBegin + 1, headerEnd).split(",");
				int lineNumber = 0;
				int spanStart = 0;
				for (int i = 0; i < header.length; ++i) {
					int lineLength = Integer.parseInt(header[i]);
					mEditable.setSpan(new TextLineSpan(lineNumber++), spanStart, spanStart + lineLength, Spanned.SPAN_INCLUSIVE_INCLUSIVE);
					spanStart += lineLength + lineBreakLength;
				}
			}
		} else {
			mEditable.setSpan(new TextLineSpan(0), 0, 0, Spanned.SPAN_INCLUSIVE_INCLUSIVE);
		}
	}

	public void setText(CharSequence text) {
		if (DEBUG) Log.v(TAG, "[setText] text: " + text.toString());
		this.beginBatchEdit();
		try {
			this.signalContentChanged();
			this.signalNotifySelectionChanged();
			this.signalDontNotifyDelphi();

			CharSequence unpackedText = unpackText(text);
			if (mEditable == null) {
				createEditable(text);
				this.restartImmInput();
			} else {
				int selEnd = getSelectionEnd();
				if (mChangeWatcher != null) {
					mEditable.removeSpan(mChangeWatcher);
				}
				mEditable.replace(0, mEditable.length(), unpackedText);
				setLineSpans(text);
				int position = Math.min(selEnd, mEditable.length());
				this.setSelection(position, position);
				this.getInputMethodManager().updateSelection(this, position, position, -1, -1);
				createChangeWatcher();
			}
		} finally {
			this.endBatchEdit();
		}
	}

	public void setInputType(int inputType) {
		if (inputType != mInputType) {
			mInputType = inputType;
			this.restartImmInput();
		}
	}

	public void setEnterAction(int enterAction) {
		if (mEnterAction != enterAction) {
			mEnterAction = enterAction;
			setText(packText(getEditable()));
		}
	}

	public void showSoftInput(boolean show) {
		SyncResultReceiver receiver = new SyncResultReceiver(mVKListeners);
		final InputMethodManager imm = getInputMethodManager();
		if (show) {
			imm.showSoftInput(this, 0, receiver);
		} else {
			imm.hideSoftInputFromWindow(getWindowToken(), 0);
			receiver.onReceiveResult(InputMethodManager.RESULT_HIDDEN, null);
		}
	}

	public void addTextListener(FMXTextListener textListener) {
		if (mListeners == null) {
			mListeners = new ArrayList<FMXTextListener>();
		}

		if (!mListeners.contains(textListener))
			mListeners.add(textListener);
	}

	public void removeTextListener(FMXTextListener textListener) {
		if (mListeners != null && mListeners.contains(textListener))
			mListeners.remove(textListener);
	}

	public void setOnEditorActionListener(OnEnterActionListener actionListener) {
		mOnEnterActionListener = actionListener;
	}

	public void addOnVKStateChangeListener(VKStateChangeListener vkListener) {
		if (mVKListeners == null) {
			mVKListeners = new ArrayList<VKStateChangeListener>();
		}
		mVKListeners.add(vkListener);
	}

	public void removeOnVKStateChangeListener(VKStateChangeListener vkListener) {
		if (mVKListeners != null) {
			mVKListeners.remove(vkListener);
		}
	}

	public void setReadOnly(boolean readonly) {
		if (mReadOnly != readonly) {
			mReadOnly = readonly;
			this.restartImmInput();
		}
	}

	public void setIsPassword(boolean isPassword) {
		if (mPassword != isPassword) {
			mPassword = isPassword;
			this.restartImmInput();
		}
	}

	public void setMultiline(boolean multiline) {
		mMultiline = multiline;
	}

	protected void beginBatchEdit() {
		if (mInputConnection != null)
			mInputConnection.beginBatchEdit();
	}

	protected void endBatchEdit() {
		if (mInputConnection != null)
			mInputConnection.endBatchEdit();
	}

	protected void signalContentChanged() {
		if (mInputConnection != null)
			mInputConnection.mContentChangeCount++;
	}

	protected void signalNotifySelectionChanged() {
		if (mInputConnection != null)
			mInputConnection.mForceNotifySelectionCount++;
	}

	protected void signalDontNotifyDelphi() {
		if (mInputConnection != null)
			mInputConnection.mDontNotifyDelphiCount++;
	}

	//region Filter methods
	public void setCharCase(int value) {
		if (value != mCharCase) {
			mCharCase = value;
			UpdateInputFilters();
		}
	}

	public void setMaxLength(int value) {
		if (value != mMaxLength) {
			mMaxLength = value;
			UpdateInputFilters();
		}
	}

	public void setFilterChar(CharSequence value) {
		if (value != mFilterChar) {
			mFilterChar = value;
			UpdateInputFilters();
		}
	}

	private void UpdateInputFilters() {
		if (mEditable != null) {
			ArrayList<InputFilter> filters = new ArrayList<InputFilter>();
			if (mCharCase == CHARCASE_UPPER) {
				filters.add(new InputFilter.AllCaps());
			} else if (mCharCase == CHARCASE_LOWER) {
				filters.add(new AllLowerInputFilter());
			}
			if (mMaxLength > 0) {
				filters.add(new InputFilter.LengthFilter(mMaxLength));
			}

			if (mFilterChar != null && mFilterChar.length() > 0) {
				filters.add(new FilterCharInputFilter(mFilterChar));
			}

			InputFilter[] filtersArray = new InputFilter[filters.size()];
			for (int i = 0; i < filters.size(); ++i)
				filtersArray[i] = filters.get(i);
			getEditable().setFilters(filtersArray);
		}
	}
	//endregion

	@Override
	public boolean onTouchEvent(MotionEvent event) {
		final int action = event.getActionMasked();
		final boolean superResult = super.onTouchEvent(event);
		final boolean touchIsFinished = (action == MotionEvent.ACTION_UP) && isFocused();

		if (touchIsFinished) {
			viewClicked();
		}

		return superResult;
	}

	@Override
	public boolean onCheckIsTextEditor() {
		return true;
	}

	@SuppressLint("InlinedApi")
	@Override
	public InputConnection onCreateInputConnection(EditorInfo outAttrs) {
		if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.HONEYCOMB) {
			outAttrs.imeOptions =
					EditorInfo.IME_FLAG_NO_EXTRACT_UI |
							EditorInfo.IME_FLAG_NO_FULLSCREEN |
							EditorInfo.IME_FLAG_NO_ACCESSORY_ACTION;
		} else {
			outAttrs.imeOptions =
					EditorInfo.IME_FLAG_NO_EXTRACT_UI |
							EditorInfo.IME_FLAG_NO_ACCESSORY_ACTION;
		}

		switch (mInputType) {
			case INPUT_NUMBER:
				outAttrs.inputType = InputType.TYPE_CLASS_NUMBER;
				break;
			case INPUT_NUMBER_DECIMAL:
				outAttrs.inputType = InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL | InputType.TYPE_NUMBER_FLAG_SIGNED;
				break;
			case INPUT_NUMBER_AND_PUNCTUATION:
				outAttrs.inputType = InputType.TYPE_CLASS_TEXT;
				break;
			case INPUT_PHONE:
				outAttrs.inputType = InputType.TYPE_CLASS_PHONE;
				break;
			case INPUT_ALPHABET:
				outAttrs.inputType = InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS;
				if (!mPassword)
					outAttrs.inputType |= InputType.TYPE_TEXT_FLAG_CAP_SENTENCES;
				break;
			case INPUT_URL:
				outAttrs.inputType = InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI;
				break;
			case INPUT_NAME_PHONE_PAD:
				outAttrs.inputType = InputType.TYPE_CLASS_PHONE;
				if (!mPassword)
					outAttrs.inputType |= InputType.TYPE_TEXT_FLAG_CAP_SENTENCES;
				break;
			case INPUT_EMAIL_ADDRESS:
				outAttrs.inputType = InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS;
				break;
			case INPUT_TEXT:
			default:
				outAttrs.inputType = InputType.TYPE_CLASS_TEXT;
				if (!mPassword)
					outAttrs.inputType |= InputType.TYPE_TEXT_FLAG_CAP_SENTENCES;
				break;
		}

		if (mPassword) {
			if ((outAttrs.inputType & InputType.TYPE_CLASS_NUMBER) == InputType.TYPE_CLASS_NUMBER)
				outAttrs.inputType |= InputType.TYPE_NUMBER_VARIATION_PASSWORD;
			else
				outAttrs.inputType |= InputType.TYPE_TEXT_VARIATION_PASSWORD;
		}

		switch (mEnterAction) {
			case ACTION_NEXT:
				outAttrs.imeOptions |= EditorInfo.IME_ACTION_NEXT;
				break;
			case ACTION_DONE:
				outAttrs.imeOptions |= EditorInfo.IME_ACTION_DONE;
				break;
			case ACTION_GO:
				outAttrs.imeOptions |= EditorInfo.IME_ACTION_GO;
				break;
			case ACTION_SEARCH:
				outAttrs.imeOptions |= EditorInfo.IME_ACTION_SEARCH;
				break;
			case ACTION_SEND:
				outAttrs.imeOptions |= EditorInfo.IME_ACTION_SEND;
				break;
			case ACTION_ENTER:
				if (!mMultiline) outAttrs.imeOptions |= EditorInfo.IME_ACTION_NEXT;
			default:
				break;
		}

		outAttrs.imeOptions |= EditorInfo.TYPE_TEXT_FLAG_MULTI_LINE;

		//outAttrs.imeOptions |= EditorInfo.IME_FLAG_NAVIGATE_NEXT;
		//outAttrs.imeOptions |= EditorInfo.IME_FLAG_NAVIGATE_PREVIOUS;
		//outAttrs.imeOptions |= EditorInfo.IME_FLAG_NO_ENTER_ACTION;

		return new ProxyInputConnection(this);
	}

	private void createEditable(CharSequence text) {
		mEditable = new SpannableStringBuilder();
		mEditable.append(unpackText(text));
		setLineSpans(text);
		Selection.setSelection(mEditable, mEditable.length());

		createChangeWatcher();
		UpdateInputFilters();
	}

	private void createChangeWatcher() {
		if (mChangeWatcher == null) mChangeWatcher = new ChangeWatcher(this);
		mEditable.setSpan(mChangeWatcher, 0, getEditable().length(), Spanned.SPAN_INCLUSIVE_INCLUSIVE |
				(0 << Spanned.SPAN_PRIORITY_SHIFT));
	}

	public Editable getEditable() {
		if (mEditable == null) {
			createEditable(EMPTY_CHARS);
		}
		return mEditable;
	}

	public void sendOnComposingText(int begin, int end) {
		if (this.mListeners != null)
			for (FMXTextListener L : this.mListeners)
				if (L != null)
					L.onComposingText(begin, end);
	}

	public void sendOnTextUpdated(CharSequence text, int position) {
		if (this.mListeners != null)
			for (FMXTextListener L : this.mListeners)
				if (L != null)
					L.onTextUpdated(text, position);
	}

	public void sendSkipKeyEvent(KeyEvent event) {
		if (this.mListeners != null) {
			for (FMXTextListener L : this.mListeners) {
				L.onSkipKeyEvent(event);
			}
		}
	}

	public int getCursorPosition() {
		int end = getSelectionEnd();
		if (end > getEditable().length()) end = getEditable().length();
		if (end < 0) end = 0;
		return end;
	}

	public int getSelectionEnd() {
		return Selection.getSelectionEnd(getEditable());
	}

	public int getSelectionStart() {
		return Selection.getSelectionStart(getEditable());
	}

	public void setSelection(int start, int end) {
		this.beginBatchEdit();
		try {
			this.signalNotifySelectionChanged();
			this.signalDontNotifyDelphi();

			int s = Math.min(start, end);
			int e = Math.max(start, end);
			int len = getEditable().length();

			if (s < 0) s = 0;
			else if (s > len) s = len;

			if (e < 0) e = 0;
			else if (e > len) e = len;

			Selection.setSelection(getEditable(), s, e);
			if (mInputConnection != null)
				mInputConnection.setSelection(s, e);

		} finally {
			this.endBatchEdit();
		}
	}

	public void setCursorPosition(int position) {
		if (DEBUG) Log.v(TAG, "[setCursorPosition] position: " + position);
		this.beginBatchEdit();

		try {
			this.signalNotifySelectionChanged();
			this.signalDontNotifyDelphi();

			if (position < 0) position = 0;
			else if (position > getEditable().length()) position = getEditable().length();

			this.setSelection(position, position);
			this.getInputMethodManager().updateSelection(this, position, position, -1, -1);
		} finally {
			this.endBatchEdit();
		}
	}

	public void skipRestart() { mSkipRestart = true; }

	public void allowRestart() { mSkipRestart = false; }

	//region CopyPaste Methods
	@SuppressLint("NewApi")
	@SuppressWarnings("deprecation")
	private void copyTextToClipboard(CharSequence text) {
		if (DEBUG) Log.v(TAG, "[copyTextToClipboard] text: " + text);
		Object service = this.getContext().getSystemService(Context.CLIPBOARD_SERVICE);
		if (service != null) {
			if ("android.content.ClipboardManager".equals(service.getClass().getName())) {
				android.content.ClipboardManager newManager = (android.content.ClipboardManager) service;
				ClipData data = ClipData.newPlainText("text", text);
				if (data != null)
					newManager.setPrimaryClip(data);
			} else if ("android.text.ClipboardManager".equals(service.getClass().getName())) {
				android.text.ClipboardManager antiqueManager = (android.text.ClipboardManager) service;
				antiqueManager.setText(text);
			}
		}
	}

	public void copySelectedText() {
		int a = getSelectionStart();
		int b = getSelectionEnd();
		if (a != b) {
			this.beginBatchEdit();
			try {
				copyTextToClipboard(getEditable().subSequence(a, b));
				this.setCursorPosition(b);
			} finally {
				this.endBatchEdit();
			}
		}
	}
	
	public void cutSelectedText() {
		int a = getSelectionStart();
		int b = getSelectionEnd();
		if (a != b) {
			copyTextToClipboard(getEditable().subSequence(a, b));
			//Removing selected text
			if (!mReadOnly) {
				if (DEBUG) Log.v(TAG, "[cutSelectedText] delete text at pos: " + a);
				this.beginBatchEdit();
				try {
					if (mChangeWatcher != null)
						mEditable.removeSpan(mChangeWatcher);
					getEditable().delete(a, b);
					this.signalContentChanged();
					checkSpanMerge();
					this.setCursorPosition(a);
					this.sendOnTextUpdated(packText(mEditable), this.getSelectionEnd());
					createChangeWatcher();
				} finally {
					this.endBatchEdit();
				}
			}
		}
	}
	
	@SuppressWarnings("deprecation")
	@SuppressLint("NewApi")
	public void pasteText() {
		if (mReadOnly)
			return;
		this.beginBatchEdit();
		try {
			this.signalContentChanged();
			CharSequence text = null;

			Object service = this.getContext().getSystemService(Context.CLIPBOARD_SERVICE);
			if (service != null) {
				if ("android.content.ClipboardManager".equals(service.getClass().getName())) {
					android.content.ClipboardManager newManager = (android.content.ClipboardManager) service;
					ClipData.Item item = newManager.getPrimaryClip().getItemAt(0);
					text = item.getText();
				} else if ("android.text.ClipboardManager".equals(service.getClass().getName())) {
					android.text.ClipboardManager antiqueManager = (android.text.ClipboardManager) service;
					text = antiqueManager.getText();
				}
			}

			if (text != null && text.length() > 0) {
				if (!mMultiline) {
					//For a single-line editors pasting only the first line of text
					String textStr = text.toString();
					if (textStr.contains(mlineBreak)) {
						text = textStr.split(mlineBreak)[0];
					}
				}
				if (DEBUG) Log.v(TAG, "[pasteText] text: " + text);
				BaseInputConnection.removeComposingSpans(getEditable());
				if (mChangeWatcher != null)
					mEditable.removeSpan(mChangeWatcher);
				int selStart = getSelectionStart();
				int selEnd = getSelectionEnd();
				if (DEBUG) Log.v(TAG, "[pasteText] selStart: " + selStart + " selEnd " + selEnd);
				int newCursorPosition = selStart + text.length();
				if (selStart != selEnd) {
					getEditable().delete(selStart, selEnd);
					checkSpanMerge();
				}
				TextLineSpan line = null;
				String textStr = text.toString();
				if (textStr.contains(mlineBreak)) {
					TextLineSpan[] spans = mEditable.getSpans(0, mEditable.length(), TextLineSpan.class);
					for (int i = 0; i < spans.length; ++i) {
						int spanStart = mEditable.getSpanStart(spans[i]);
						int spanEnd = mEditable.getSpanEnd(spans[i]);
						if (selStart >= spanStart && selStart <= spanEnd) {
							line = spans[i];
							break;
						}
					}
				}
				getEditable().insert(selStart, text);
				if (line != null && textStr.contains(mlineBreak)) {
					int lineStart = mEditable.getSpanStart(line);
					int lineEnd = mEditable.getSpanEnd(line);
					TextLineSpan[] spans = mEditable.getSpans(lineEnd + 1, mEditable.length(), TextLineSpan.class);
					//Changing first line
					int breakIndex = textStr.indexOf(mlineBreak);
					mEditable.setSpan(line, lineStart, selStart + breakIndex, Spannable.SPAN_INCLUSIVE_INCLUSIVE);
					selStart += breakIndex + mlineBreak.length();
					int textStrShift = breakIndex + mlineBreak.length();
					while (textStr.indexOf(mlineBreak, textStrShift) >= 0) {
						breakIndex = textStr.indexOf(mlineBreak, textStrShift);
						if (breakIndex >= 0) {
							mEditable.setSpan(new TextLineSpan(0), selStart, selStart + breakIndex - textStrShift, Spannable.SPAN_INCLUSIVE_INCLUSIVE);
							selStart += breakIndex - textStrShift + mlineBreak.length();
							textStrShift = breakIndex + mlineBreak.length();
						}
					}
					//Changing last line
					if ((lineEnd - selStart) > 0) {
						mEditable.setSpan(new TextLineSpan(0), selStart, lineEnd, Spannable.SPAN_INCLUSIVE_INCLUSIVE);
					}
					//Removing spans after pasted text
					for (int i = 0; i < spans.length; ++i) {
						lineStart = mEditable.getSpanStart(spans[i]);
						lineEnd = mEditable.getSpanEnd(spans[i]);
						mEditable.removeSpan(spans[i]);
						mEditable.setSpan(new TextLineSpan(0), lineStart, lineEnd, Spannable.SPAN_INCLUSIVE_INCLUSIVE);
					}
					//Enumerate all current spans and assign line numbers
					spans = mEditable.getSpans(0, mEditable.length(), TextLineSpan.class);
					for (int i = 0; i < spans.length; ++i)
						spans[i].setLineNumber(i);
				}
				this.setCursorPosition(newCursorPosition);
				this.sendOnTextUpdated(packText(mEditable), this.getSelectionEnd());
				createChangeWatcher();
			}
		} finally {
			this.endBatchEdit();
		}
	}
	//endregion

	public void checkSpanMerge() {
		TextLineSpan[] spans = getEditable().getSpans(0, getEditable().length(), TextLineSpan.class);
		Arrays.sort(spans);
		if (DEBUG) Log.v(TAG, "[checkSpanMerge] length: " + spans.length);
		if (spans.length > 1) {
			TextLineSpan prevLine = spans[0];
			int prevLineStart = getEditable().getSpanStart(prevLine);
			int prevLineEnd = getEditable().getSpanEnd(prevLine);
			int lineNumber = 1;
			for (int i = 1; i < spans.length; ++i) {
				TextLineSpan line = spans[i];
				line.setLineNumber(lineNumber++);
				int lineStart = getEditable().getSpanStart(line);
				int lineEnd = getEditable().getSpanEnd(line);
				if (prevLineEnd >= lineStart) {
					if (DEBUG) Log.v(TAG, "[checkSpanMerge] span: " + i + " line: " + line.getLineNumber() + " prevLineEnd: " + prevLineEnd + " lineStart: " + lineStart);
					getEditable().removeSpan(line);
					line = null;
					prevLineEnd = Math.max(lineEnd, prevLineEnd);
					getEditable().setSpan(prevLine, prevLineStart, prevLineEnd, Spannable.SPAN_INCLUSIVE_INCLUSIVE);
				} else {
					prevLine = line;
					prevLineStart = getEditable().getSpanStart(prevLine);
					prevLineEnd = getEditable().getSpanEnd(prevLine);
				}
			}
		}
	}

	public void setInputConnection(ProxyInputConnection connection) {
		mInputConnection = connection;
	}

	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if (DEBUG) Log.v(TAG, "[onKeyDown] keyCode: " + keyCode);
		final boolean superResult = super.onKeyDown(keyCode, event);
		if ((event.getFlags() & KeyEvent.FLAG_EDITOR_ACTION) != 0) {
			if (mOnEnterActionListener != null) {
				mOnEnterActionListener.onAction(this, EditorInfo.IME_NULL, event);
			}
		}
		return superResult;
	}
	
	@Override 
	public Parcelable onSaveInstanceState() {
		SavedState ss = new SavedState(super.onSaveInstanceState(), getSelectionStart(), getSelectionEnd(), packText(getEditable()));
		return ss;
	}
	
	@Override
	public void onRestoreInstanceState(Parcelable state) {
		if (!(state instanceof SavedState)) {
			super.onRestoreInstanceState(state);
			return;
		}
		
		SavedState ss = (SavedState)state;
		super.onRestoreInstanceState(ss.getSuperState());
		setText(ss.mText);
		this.setSelection(ss.mSelStart, ss.mSelEnd);
		this.getInputMethodManager().updateSelection(this, ss.mSelStart, ss.mSelEnd, -1, -1);
	}

	protected void restartImmInput() {
		InputMethodManager imm = this.getInputMethodManager();
		if (imm != null) {
			imm.restartInput(this);
		}
	}

	protected InputMethodManager getInputMethodManager() {
		return (InputMethodManager) getContext().getSystemService(Context.INPUT_METHOD_SERVICE);
	}
	
	//@SuppressLint("NewApi")
	private void viewClicked() {
		showSoftInput(true);
	}

	static class SavedState extends BaseSavedState {
		int mSelStart;
		int mSelEnd;
		CharSequence mText;

		public SavedState(Parcelable superState, int selStart, int selEnd, CharSequence text) {
			super(superState);
			mSelStart = selStart;
			mSelEnd = selEnd;
			mText = text;
		}

		@Override
		public void writeToParcel(Parcel out, int flags) {
			super.writeToParcel(out, flags);
			out.writeInt(mSelStart);
			out.writeInt(mSelEnd);
			TextUtils.writeToParcel(mText, out, flags);
		}

		private SavedState(Parcel in) {
			super(in);
			mSelStart = in.readInt();
			mSelEnd = in.readInt();
			mText = TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(in);
		}

		public static final Parcelable.Creator<SavedState> CREATOR
				= new Parcelable.Creator<SavedState>() {
			public SavedState createFromParcel(Parcel in) {
				return new SavedState(in);
			}

			public SavedState[] newArray(int size) {
				return new SavedState[size];
			}
		};
	}
	
	private static class ProxyInputConnection extends BaseInputConnection {
		@SuppressWarnings("unused")
		private static final String TAG = "ProxyInputConnection";
		private FMXTextEditorProxy mTargetView;
		private int mBatchEditCount = 0;
		private int mOldSelStart = -1;
		private int mOldSelEnd = -1;
		private int mOldCompStart = -1;
		private int mOldCompEnd = -1;
		private int mContentChangeCount = 0;
		private boolean mMonitorExtractedText = false;
		private ExtractedTextRequest mExtractTextReq = null;
		private int mForceNotifySelectionCount = 0;
		private int mDontNotifyDelphiCount = 0;

		public ProxyInputConnection(View targetView) {
			super(targetView, true);
			mTargetView = (FMXTextEditorProxy) targetView;
			mTargetView.setInputConnection(this);
		}
		
		@Override
		public Editable getEditable() {
			return mTargetView.getEditable();
		}

		@Override
		public boolean commitText(CharSequence text, int newCursorPosition) {
			if (DEBUG) Log.v(TAG, "[commitText] text: " + text + " prev text: " + getEditable().toString());
			text = text.toString().replaceAll("\\u200B", "");
			mTargetView.createChangeWatcher();
			if (!mTargetView.mMultiline) {
				if (text.equals(mTargetView.mlineBreak)) {
					if (DEBUG) Log.v(TAG, "[commitText] skip line break");
					InputMethodManager imm = mTargetView.getInputMethodManager();
					if (imm != null && imm.isActive(mTargetView)) {
						imm.hideSoftInputFromWindow(mTargetView.getWindowToken(), 0);
					}
					return false;
				}
				text = text.toString().replace(mTargetView.mlineBreak, EMPTY_CHARS);
			}

			if (!mTargetView.mReadOnly) {
				this.beginBatchEdit();
				try {
					if (mTargetView.mMultiline && text.toString().contains(mTargetView.mlineBreak)) {
						this.removeComposingSpans(getEditable());
						removeAllLineSpans();
					}
					mTargetView.allowRestart();
					boolean result = super.commitText(text, newCursorPosition);
					if (result) {
						mContentChangeCount++;
						if (DEBUG) Log.v(TAG, "[commitText] changed. text: " + getEditable().toString());
					}
					if (mTargetView.mMultiline && text.toString().contains(mTargetView.mlineBreak)) {
						recalculateLineSpans();
					}
					return result;
				} finally {
					this.endBatchEdit();
				}
			} else {
				return false;
			}
		}

		void recalculateLineSpans() {
			removeAllLineSpans();

			int lineNumber = 0;
			int spanStart = 0;
			int spanEnd = 0;
			int length = getEditable().length();
			if (DEBUG) Log.v(TAG, "[recalculateLineSpans] text: " +  getEditable().toString() + " length: " + length);

			for (String line : getEditable().toString().split(mTargetView.mlineBreak, -1)) {
				spanEnd = spanStart + line.length();
				if (spanEnd > length){
					spanEnd = length;
					if (spanStart > spanEnd){
						spanStart = spanEnd;
					}
				}
				if (DEBUG) Log.v(TAG, "[recalculateLineSpans] line index: " + lineNumber + " start: " + spanStart + " end: " + spanEnd + " line length " + line.length() + " line: [" + line + "]");
				getEditable().setSpan(new TextLineSpan(lineNumber++), spanStart, spanEnd, Spanned.SPAN_INCLUSIVE_INCLUSIVE);
				spanStart = spanEnd + 1;
			}
		}

		void removeAllLineSpans() {
			TextLineSpan[] spans = getEditable().getSpans(0, getEditable().length(), TextLineSpan.class);
			for (int i = spans.length - 1; i >= 0 ; --i) {
				getEditable().removeSpan(spans[i]);
				spans[i] = null;
			}
		}

		@Override
		public boolean setComposingText(CharSequence text, int newCursorPosition) {
			int composingStart = BaseInputConnection.getComposingSpanStart(getEditable());
			int composingEnd = BaseInputConnection.getComposingSpanEnd(getEditable());
			if (DEBUG) Log.v(TAG, "[setComposingText] text " + text + " composingStart " + composingStart + " composingEnd " + composingEnd);
			boolean hasComposing = composingStart != composingEnd && (composingStart > 0 || composingEnd > 0);
			if (!mTargetView.mReadOnly && (hasComposing || text.length() > 0)) {
				this.beginBatchEdit();
				try {
					mTargetView.allowRestart();
					mContentChangeCount++;
					return super.setComposingText(text, newCursorPosition);
				} finally {
					this.endBatchEdit();
				}
			}
			else {
				return false;
			}
		}

		@Override
		public boolean deleteSurroundingText(int beforeLength, int afterLength) {
			if (!mTargetView.mReadOnly) {
				this.beginBatchEdit();
				try {
					mContentChangeCount++;
					return super.deleteSurroundingText(beforeLength, afterLength);
				} finally {
					this.endBatchEdit();
				}
			} else {
				return false;
			}
		}

		@Override
		public boolean sendKeyEvent(KeyEvent event) {
			final boolean superResult = super.sendKeyEvent(event);
			if ((event.getAction() == KeyEvent.ACTION_DOWN) && ((event.getFlags() & KeyEvent.FLAG_EDITOR_ACTION) != 0)) {
				this.beginBatchEdit();
				try {
					removeComposingSpans(getEditable());
				} finally {
					this.endBatchEdit();
				}
			}
			else if (event.getKeyCode() == KeyEvent.KEYCODE_DEL && !mTargetView.mReadOnly) {
				int a = mTargetView.getSelectionStart();
				int b = mTargetView.getSelectionEnd();
				boolean deleteSelected = (a != b || a > 0); //cursor is not at the beginning of the line
				if (event.getAction() == KeyEvent.ACTION_DOWN) {
					this.beginBatchEdit();
					try {
						if (mTargetView.mChangeWatcher != null)
							getEditable().removeSpan(mTargetView.mChangeWatcher);
						if (deleteSelected) {
							int charsToDelete = 0;
							if (a != b) {
								//has selection
								charsToDelete = b - a;
								if (charsToDelete > 0) {
									Selection.setSelection(getEditable(), a, a);
									this.deleteSurroundingText(0, charsToDelete);
								}
							} else {
								if (getEditable().length() > 0) {
									if (Character.isLowSurrogate(getEditable().charAt(a - 1)))
										charsToDelete = 2;
									else
										charsToDelete = Character.charCount(Character.codePointAt(getEditable(), a - 1));
								}
								if (charsToDelete > 0) {
									this.deleteSurroundingText(charsToDelete, 0);
								}
							}
						} else if (a == 0) {
							deleteSelected = true;
							this.deleteSurroundingText(1, 0);
						}
						mTargetView.createChangeWatcher();
					} finally {
						this.endBatchEdit();
					}
				}
				if (deleteSelected)
					mTargetView.sendSkipKeyEvent(new KeyEvent(event));
				return true;
			}
			else if (event.getAction() == KeyEvent.ACTION_DOWN)
			{
				mTargetView.skipRestart();
			}
			return superResult;
		}

		private ExtractedText newExtractedText(ExtractedTextRequest request) {
			Editable content = this.getEditable();
			ExtractedText ex = new ExtractedText();
			ex.text = content.subSequence(0, content.length());
			ex.selectionStart = Selection.getSelectionStart(content);
			ex.selectionEnd = Selection.getSelectionEnd(content);
			ex.partialEndOffset = -1;
			ex.partialStartOffset = -1;
			ex.startOffset = 0;
			if (!mTargetView.mMultiline)
				ex.flags |=  ExtractedText.FLAG_SINGLE_LINE;
			if (DEBUG) Log.v(TAG, "newExtractedText] result: " + ex);
			return ex;
		}
		
		@Override
		public ExtractedText getExtractedText (ExtractedTextRequest request,
											   int flags) {
			if (DEBUG) Log.v(TAG, "[getExtractedText] request: " + request + " flags: " + flags);
			this.mMonitorExtractedText = (flags & InputConnection.GET_EXTRACTED_TEXT_MONITOR) != 0;
			this.mExtractTextReq = request;
			return this.newExtractedText(request);
		}
		
		@Override
		public boolean setComposingRegion(int start, int end) {
			if (DEBUG) Log.v(TAG, "[setComposingRegion] start: " + start + " end: " + end);
			this.beginBatchEdit();
			try {
				if (start == end) {
					this.removeComposingSpans(this.getEditable());
					return true;
				}

				return super.setComposingRegion(start, end);
			} finally {
				this.endBatchEdit();
			}
		}

		@Override
		public boolean setSelection(int start, int end) {
			this.beginBatchEdit();
			try {
				if (end < start) {
					int aux = end;
					end = start;
					start = aux;
				}

				if (end > start && mDontNotifyDelphiCount == 0) {
					start = end;
				}

				return super.setSelection(start, end);
			} finally {
				this.endBatchEdit();
			}
		}

		@Override
		public boolean beginBatchEdit() {
			this.mBatchEditCount++;

			if (this.mBatchEditCount == 1) {
				if (DEBUG) Log.v(TAG, "[beginBatchEdit] First in");
				Editable content = this.getEditable();
				mOldSelStart = Selection.getSelectionStart(content);
				mOldSelEnd = Selection.getSelectionEnd(content);
				mOldCompStart = this.getComposingSpanStart(content);
				mOldCompEnd = this.getComposingSpanEnd(content);
				mContentChangeCount = 0;
				mForceNotifySelectionCount = 0;
				mDontNotifyDelphiCount = 0;
			}

			return true;
		}

		@Override
		public boolean endBatchEdit() {
			try {
				if (this.mBatchEditCount == 1) {
					boolean contentChanged = mContentChangeCount > 0;
					if (DEBUG) Log.v(TAG, "[endBatchEdit] Last out");
					if (contentChanged)
						mTargetView.checkSpanMerge();

					Editable content = this.getEditable();
					int newSelStart = Selection.getSelectionStart(content);
					int newSelEnd = Selection.getSelectionEnd(content);
					final int newCompStart = this.getComposingSpanStart(content);
					final int newCompEnd = this.getComposingSpanEnd(content);
					boolean newIsRangeSelection = newSelStart != newSelEnd;
					boolean selectionChanged = (newSelStart != mOldSelStart) || (newSelEnd != mOldSelEnd) || (mForceNotifySelectionCount > 0);
					boolean composingChanged = (newCompStart != mOldCompStart) || (newCompEnd != mOldCompEnd) || (mForceNotifySelectionCount > 0);

					InputMethodManager imm = mTargetView.getInputMethodManager();

					if (selectionChanged || contentChanged) {
						this.setSelection(newSelStart,newSelEnd);
						if (!contentChanged) {
							imm.restartInput(mTargetView);
							imm.updateSelection(mTargetView, newSelStart, newSelEnd, -1, -1);
						}
					}
					
					if (mMonitorExtractedText && (mExtractTextReq != null) && (selectionChanged || contentChanged)) {
						if (DEBUG) Log.v(TAG, "[endBatchEdit] updateExtractedText");
					    imm.updateExtractedText(mTargetView, mExtractTextReq.token, this.newExtractedText(mExtractTextReq));
					}


					if (contentChanged || (selectionChanged && (!newIsRangeSelection)))  // range selection must not be "callbacked" to delphi
						if (mDontNotifyDelphiCount == 0) {
							if (DEBUG) Log.v(TAG, "[endBatchEdit] sendOnTextUpdated");
							mTargetView.sendOnTextUpdated(mTargetView.packText(content), mTargetView.getSelectionEnd());
						}
					
					if (composingChanged) {
						if (DEBUG) Log.v(TAG, "[endBatchEdit] sendOnComposingText new: ("+newCompStart+","+newCompEnd+") old:("+mOldCompStart+","+mOldCompEnd+")");
						mTargetView.sendOnComposingText(newCompStart, newCompEnd);
					}

						
				}
			} finally {
				this.mBatchEditCount--;
			}

			return this.mBatchEditCount > 0;			
		}
	}

	private static class SyncResultReceiver extends ResultReceiver {
		private ArrayList<VKStateChangeListener> mListeners;

		public SyncResultReceiver(ArrayList<VKStateChangeListener> listeners) {
			super(null);
			mListeners = new ArrayList<VKStateChangeListener>(listeners);
		}

		@Override
		public void onReceiveResult(int result, Bundle data) {
			switch (result) {
				case InputMethodManager.RESULT_UNCHANGED_SHOWN:
				case InputMethodManager.RESULT_SHOWN:
					for (VKStateChangeListener listener : mListeners) {
						listener.onVirtualKeyboardShown();
					}
					break;
				case InputMethodManager.RESULT_UNCHANGED_HIDDEN:
				case InputMethodManager.RESULT_HIDDEN:
					for (VKStateChangeListener listener : mListeners) {
						listener.onVirtualKeyboardHidden();
					}
					break;
				default:
					break;
			}
		}
	}
	
	private class ChangeWatcher implements TextWatcher, SpanWatcher {
		@SuppressWarnings("unused")
		private static final String TAG = "ChangeWatcher";

		private FMXTextEditorProxy mProxyView;

		public ChangeWatcher(FMXTextEditorProxy proxyView) {
			mProxyView = proxyView;
		}

		public void beforeTextChanged(CharSequence buffer, int start,
									  int before, int after) {
			if (DEBUG) Log.v(TAG, "[beforeTextChanged] text: " + buffer + " start " + start + " before " + before + " after " + after);
		}

		public void onTextChanged(CharSequence buffer, int start, int before, int after) {
			if (DEBUG) Log.v(TAG, "[onTextChanged] text: " + buffer + " start " + start + " before " + before + " after " + after);
		}

		public void afterTextChanged(Editable buffer) {
			if (DEBUG) Log.v(TAG, "[afterTextChanged] text: " + buffer);
		}

		public void onSpanChanged(Spannable buf, Object what, int s, int e, int st, int en) {
			if (DEBUG) Log.v(TAG, "[onSpanChanged] s " + s + " e: " + e + " ClassName " + what.getClass().getCanonicalName());
		}

		public void onSpanAdded(Spannable buf, Object what, int s, int e) {
			if (DEBUG) Log.v(TAG, "[onSpanAdded] s " + s + " e: " + e + " ClassName " + what.getClass().getCanonicalName());
		}

		public void onSpanRemoved(Spannable buf, Object what, int s, int e) {
			if (DEBUG) Log.v(TAG, "[onSpanRemoved] s " + s + " e: " + e + " ClassName " + what.getClass().getCanonicalName());
		}
	}

	private class AllLowerInputFilter implements InputFilter {
		public CharSequence filter(CharSequence source, int start, int end,
								   Spanned dest, int dstart, int dend) {
			for (int i = start; i < end; i++) {
				if (Character.isUpperCase(source.charAt(i))) {
					char[] v = new char[end - start];
					TextUtils.getChars(source, start, end, v, 0);
					String s = new String(v).toLowerCase();

					if (source instanceof Spanned) {
						SpannableString sp = new SpannableString(s);
						TextUtils.copySpansFrom((Spanned) source,
								start, end, null, sp, 0);
						return sp;
					} else {
						return s;
					}
				}
			}

			return null; // keep original
		}
	}

	private class FilterCharInputFilter implements InputFilter {
		private String mFilter;

		@SuppressWarnings("unused")
		private static final String TAG = "FilterCharInputFilter";

		public FilterCharInputFilter(CharSequence filterChar) {
			mFilter = filterChar.toString();
		}

		public CharSequence filter(CharSequence source, int start, int end,
								   Spanned dest, int dstart, int dend) {
			if (DEBUG) Log.v(TAG, "[filter] source " + source + " start: " + start + " end " + end + " dstart: " + dstart + " dend " + dend);
			boolean keepOriginal = true;
			StringBuilder sb = new StringBuilder(end - start);
			for (int i = start; i < end; i++) {
				char c = source.charAt(i);
				if (DEBUG) Log.v(TAG, "[filter] [" + source + "] sub [" + source.subSequence(i, i + 1) + "]");
				if (mFilter.contains(source.subSequence(i, i + 1)))
					sb.append(c);
				else
					keepOriginal = false;
			}
			if (keepOriginal)
				return null;
			else {
				if (source instanceof Spanned) {
					SpannableString sp = new SpannableString(sb);
					TextUtils.copySpansFrom((Spanned) source, start, sb.length(), null, sp, 0);
					return sp;
				} else {
					return sb;
				}
			}
		}
	}
}