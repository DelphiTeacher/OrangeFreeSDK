﻿TMemo 在 三星 华为 的部分 机器上 输入法输入 多行后，发生错误（第 3 行 和 第 4 行 突然对调）。

http://bbs.2ccc.com/topic.asp?topicid=544685
https://quality.embarcadero.com/browse/RSP-20107
https://quality.embarcadero.com/browse/RSP-16935
https://quality.embarcadero.com/browse/RSP-17346
https://quality.embarcadero.com/browse/RSP-18614

临时解决办法

复制
FMX.Platform.Android.pas
到你的工程
找到
    if FContextMenuPopup = nil then
在这行 之前 
加入代码
//fix by Alysson Cunha
//https://quality.embarcadero.com/browse/RSP-16935
    FCopyButton := nil;
    FPasteButton := nil;
    FCutButton := nil;
如果您已经使用 不看后悔 内的 代码补丁。那么这个修改已经存在了。


工程列表（Project Manager）中
选择工程 选择 安卓平台 展开 Libraries
禁用 fmx.dex.jar

Libraries 右键，Add ，选择 fmx_Corrected10.2.3.jar（或更适合您的版本）

如果您不需要 谷歌的 
google-play-services.dex.jar 以及 google-analytics-v2.dex.jar 功能。(Rad 10.2.2 或更低版本)
google-play-services-ads-xxx.dex.jar 以及 google-play-services-analytics-xxx.dex.jar 功能。(Rad 10.2.3 或更高版本)
可以直接禁用掉他们。这样就没有广告了。

重新编译即可。