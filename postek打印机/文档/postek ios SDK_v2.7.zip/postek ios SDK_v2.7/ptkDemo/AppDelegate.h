//
//  AppDelegate.h
//  ptkDemo
//
//  Created by SDP-MAC on 2017/9/29.
//  Copyright © 2017年 Postek. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

